package com.hotmail.thang.ui.view.orderedit;

public class ProductInfoChangeEvent {

	public ProductInfoChangeEvent() {
		// Nothing to do here
	}
}

package com.hotmail.thang.ui.view.orderedit;

/**
 * Event object sent when an order has been updated.
 */
public class OrderUpdated {

	public OrderUpdated() {
		// This is just a marker class to invoke the correct listener
	}
}

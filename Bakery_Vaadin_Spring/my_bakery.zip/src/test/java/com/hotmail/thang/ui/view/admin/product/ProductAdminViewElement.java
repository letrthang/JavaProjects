package com.hotmail.thang.ui.view.admin.product;

public class ProductAdminViewElement extends ProductAdminViewDesignElement implements CrudViewElement {

}
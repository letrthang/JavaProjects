package com.hotmail.thang.ui.view.admin.user;

import com.hotmail.thang.ui.view.admin.product.CrudViewElement;

public class UserAdminViewElement extends UserAdminViewDesignElement implements CrudViewElement {

}
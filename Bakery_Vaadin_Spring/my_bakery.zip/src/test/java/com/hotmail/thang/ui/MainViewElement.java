package com.hotmail.thang.ui;

public class MainViewElement extends MainViewDesignElement {

}